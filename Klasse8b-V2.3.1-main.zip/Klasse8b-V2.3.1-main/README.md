# Klasse8b-V2.3.1            
                    
## Changelog               
                    
### Item:                     
                                        
-replaced texture "Holzmann70's Totem" (pattern: "Holzmann70's Totem")                     
-replaced texture "Holzmann70's Piercer" (ipattern: "Piercer") (netherite)                     
                     
                     
(pattern="exact name")                     
(ipattern="exact name and non exact name")                     
                     
Bitte benachrichtige mich, wenn du einen Bug gefunden hast, wenn ich etwas vergessen habe, oder wenn du möchtest, dass eine weitere Textur hinzugefügt werden soll.                     
                     
## Download-Link (Mediafire)                     
                     
[Klasse8b-v2.3.1](https://www.mediafire.com/file/deyd67q6hxmcz4h/klasse8b_v2.3.1.zip/file)                    
                              
## Wie installiere ich das Texture-Pack?                     
                     
1. Gebe in der Suchleiste deines PCs den Speicherpfad "%appdata%" ein und drücke Enter.                     
2. Navigiere in dem Dateiordner zu ".minecraft" und doppelklicke diesen.                         
3. Finde den Order "resource-packs" und öffne ihn.                       
4. Lade das Texture Pack herunter und ziehe die Zip-Datei in den Ordner.                                  
5. Öffne Minecraft und gehe zu "Options" , dann zu "Texture-Packs".                       
6. Jetzt brauchst du das Texture Pack nur noch zu aktivieren und auf den Server zu joinen!    
